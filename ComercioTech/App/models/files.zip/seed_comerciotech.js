// ============================================================
// Script de carga de datos de simulacion - ComercioTech NoSQL
// Ejecutar dentro del contenedor Docker con:
//   mongosh "mongodb://usuario:password@localhost:27017/comerciotech" seed_comerciotech.js
// o copiando y pegando en una sesion interactiva de mongosh.
// ============================================================

use("comerciotech");

// ------------------------------------------------------------
// 1. productos
// ------------------------------------------------------------
db.productos.deleteMany({});
db.productos.insertMany([
  {
    _id: ObjectId("665f1a0000000000000a0001"),
    sku: "LAP-DELL-XPS15-001",
    id_proveedor_sql: 482,
    nombre: "Laptop Dell XPS 15",
    categoria: "laptops",
    descripcion: "Laptop de alto rendimiento para diseno y desarrollo de software",
    precio_actual: 1250000,
    moneda: "CLP",
    stock_disponible: 34,
    activo: true,
    atributos: {
      ram_gb: 16,
      procesador: "Intel i7-13700H",
      almacenamiento_gb: 512,
      tipo_pantalla: "OLED 15.6 pulgadas",
      tipo_switch: null,
      tipo_licencia: null
    },
    variantes: [
      { color: "Plata", voltaje: "110V", sku_variante: "LAP-DELL-XPS15-001-PL", stock: 10 },
      { color: "Negro", voltaje: "220V", sku_variante: "LAP-DELL-XPS15-001-NG", stock: 24 }
    ],
    especificaciones_fabricante: { garantia_meses: 12, peso_kg: 1.8, fabricante: "Dell Inc." },
    rating_promedio: 4.6,
    total_resenas: 128,
    fecha_creacion: ISODate("2026-01-15T10:00:00Z"),
    fecha_actualizacion: ISODate("2026-06-18T09:32:00Z")
  },
  {
    _id: ObjectId("665f1a0000000000000a0002"),
    sku: "TEC-LOGI-MX-002",
    id_proveedor_sql: 510,
    nombre: "Teclado Mecanico Logitech MX",
    categoria: "teclados",
    descripcion: "Teclado mecanico inalambrico para productividad",
    precio_actual: 89990,
    moneda: "CLP",
    stock_disponible: 152,
    activo: true,
    atributos: {
      ram_gb: null,
      procesador: null,
      tipo_switch: "Tactil silencioso",
      conectividad: "Bluetooth / USB receptor",
      tipo_licencia: null
    },
    variantes: [
      { color: "Grafito", voltaje: null, sku_variante: "TEC-LOGI-MX-002-GR", stock: 90 },
      { color: "Blanco", voltaje: null, sku_variante: "TEC-LOGI-MX-002-BL", stock: 62 }
    ],
    especificaciones_fabricante: { garantia_meses: 24, peso_kg: 0.81, fabricante: "Logitech" },
    rating_promedio: 4.8,
    total_resenas: 342,
    fecha_creacion: ISODate("2025-11-02T08:00:00Z"),
    fecha_actualizacion: ISODate("2026-06-19T07:14:00Z")
  },
  {
    _id: ObjectId("665f1a0000000000000a0003"),
    sku: "SOFT-ADOBE-CC-003",
    id_proveedor_sql: 601,
    nombre: "Adobe Creative Cloud - Licencia Anual",
    categoria: "software",
    descripcion: "Suite completa de diseno grafico y edicion de video",
    precio_actual: 215000,
    moneda: "CLP",
    stock_disponible: 9999,
    activo: true,
    atributos: {
      ram_gb: null,
      procesador: null,
      tipo_switch: null,
      tipo_licencia: "Suscripcion anual",
      dispositivos_permitidos: 2
    },
    variantes: [
      { color: null, voltaje: null, sku_variante: "SOFT-ADOBE-CC-003-1Y", stock: 9999 }
    ],
    especificaciones_fabricante: { garantia_meses: null, fabricante: "Adobe Inc.", entrega: "Codigo digital por email" },
    rating_promedio: 4.3,
    total_resenas: 67,
    fecha_creacion: ISODate("2025-09-20T12:00:00Z"),
    fecha_actualizacion: ISODate("2026-06-10T16:00:00Z")
  },
  {
    _id: ObjectId("665f1a0000000000000a0004"),
    sku: "MON-LG-ULTRA-004",
    id_proveedor_sql: 482,
    nombre: "Monitor LG UltraWide 34 pulgadas",
    categoria: "monitores",
    descripcion: "Monitor curvo para multitarea y diseno",
    precio_actual: 459990,
    moneda: "CLP",
    stock_disponible: 21,
    activo: true,
    atributos: {
      resolucion: "3440x1440",
      tasa_refresco_hz: 144,
      panel: "IPS",
      tipo_switch: null,
      tipo_licencia: null
    },
    variantes: [
      { color: "Negro", voltaje: "220V", sku_variante: "MON-LG-ULTRA-004-NG", stock: 21 }
    ],
    especificaciones_fabricante: { garantia_meses: 36, peso_kg: 7.2, fabricante: "LG Electronics" },
    rating_promedio: 4.7,
    total_resenas: 54,
    fecha_creacion: ISODate("2026-02-01T09:00:00Z"),
    fecha_actualizacion: ISODate("2026-06-17T11:20:00Z")
  }
]);

// ------------------------------------------------------------
// 2. carritos
// ------------------------------------------------------------
db.carritos.deleteMany({});
db.carritos.insertMany([
  {
    _id: ObjectId("665f2b0000000000000b0001"),
    id_cliente_sql: 9123,
    session_id: "sess_abc123",
    items: [
      { producto_id: ObjectId("665f1a0000000000000a0001"), sku: "LAP-DELL-XPS15-001", nombre: "Laptop Dell XPS 15", cantidad: 1, precio_unitario: 1250000 },
      { producto_id: ObjectId("665f1a0000000000000a0002"), sku: "TEC-LOGI-MX-002", nombre: "Teclado Mecanico Logitech MX", cantidad: 2, precio_unitario: 89990 }
    ],
    estado: "activo",
    total: 1429980,
    fecha_creacion: ISODate("2026-06-19T14:02:00Z"),
    fecha_actualizacion: ISODate("2026-06-19T14:10:00Z"),
    ttl_expira: ISODate("2026-06-26T14:02:00Z")
  },
  {
    _id: ObjectId("665f2b0000000000000b0002"),
    id_cliente_sql: null,
    session_id: "sess_guest_77f2",
    items: [
      { producto_id: ObjectId("665f1a0000000000000a0003"), sku: "SOFT-ADOBE-CC-003", nombre: "Adobe Creative Cloud - Licencia Anual", cantidad: 1, precio_unitario: 215000 }
    ],
    estado: "activo",
    total: 215000,
    fecha_creacion: ISODate("2026-06-19T15:40:00Z"),
    fecha_actualizacion: ISODate("2026-06-19T15:40:00Z"),
    ttl_expira: ISODate("2026-06-26T15:40:00Z")
  },
  {
    _id: ObjectId("665f2b0000000000000b0003"),
    id_cliente_sql: 9087,
    session_id: "sess_def456",
    items: [
      { producto_id: ObjectId("665f1a0000000000000a0004"), sku: "MON-LG-ULTRA-004", nombre: "Monitor LG UltraWide 34 pulgadas", cantidad: 1, precio_unitario: 459990 }
    ],
    estado: "convertido",
    total: 459990,
    fecha_creacion: ISODate("2026-06-18T11:00:00Z"),
    fecha_actualizacion: ISODate("2026-06-18T11:25:00Z"),
    ttl_expira: ISODate("2026-06-25T11:00:00Z")
  }
]);

// ------------------------------------------------------------
// 3. logs_navegacion
// ------------------------------------------------------------
db.logs_navegacion.deleteMany({});
db.logs_navegacion.insertMany([
  {
    _id: ObjectId("665f3c0000000000000c0001"),
    id_cliente_sql: 9123,
    session_id: "sess_abc123",
    evento: "vista_producto",
    producto_id: ObjectId("665f1a0000000000000a0001"),
    sku: "LAP-DELL-XPS15-001",
    categoria: "laptops",
    metadata: { origen: "home_recomendados", dispositivo: "mobile", duracion_vista_seg: 12 },
    timestamp: ISODate("2026-06-19T13:55:02Z")
  },
  {
    _id: ObjectId("665f3c0000000000000c0002"),
    id_cliente_sql: 9123,
    session_id: "sess_abc123",
    evento: "vista_producto",
    producto_id: ObjectId("665f1a0000000000000a0002"),
    sku: "TEC-LOGI-MX-002",
    categoria: "teclados",
    metadata: { origen: "busqueda", dispositivo: "mobile", duracion_vista_seg: 8 },
    timestamp: ISODate("2026-06-19T13:58:40Z")
  },
  {
    _id: ObjectId("665f3c0000000000000c0003"),
    id_cliente_sql: 9123,
    session_id: "sess_abc123",
    evento: "agregar_carrito",
    producto_id: ObjectId("665f1a0000000000000a0001"),
    sku: "LAP-DELL-XPS15-001",
    categoria: "laptops",
    metadata: { origen: "ficha_producto", dispositivo: "mobile", duracion_vista_seg: null },
    timestamp: ISODate("2026-06-19T14:02:00Z")
  },
  {
    _id: ObjectId("665f3c0000000000000c0004"),
    id_cliente_sql: null,
    session_id: "sess_guest_77f2",
    evento: "busqueda",
    producto_id: null,
    sku: null,
    categoria: "software",
    metadata: { termino_busqueda: "adobe creative cloud", dispositivo: "desktop", resultados_encontrados: 6 },
    timestamp: ISODate("2026-06-19T15:38:10Z")
  },
  {
    _id: ObjectId("665f3c0000000000000c0005"),
    id_cliente_sql: 9456,
    session_id: "sess_ghi789",
    evento: "vista_producto",
    producto_id: ObjectId("665f1a0000000000000a0004"),
    sku: "MON-LG-ULTRA-004",
    categoria: "monitores",
    metadata: { origen: "click_categoria", dispositivo: "desktop", duracion_vista_seg: 25 },
    timestamp: ISODate("2026-06-19T16:10:15Z")
  }
]);

// ------------------------------------------------------------
// 4. recomendaciones
// ------------------------------------------------------------
db.recomendaciones.deleteMany({});
db.recomendaciones.insertMany([
  {
    _id: ObjectId("665f4d0000000000000d0001"),
    id_cliente_sql: 9123,
    productos_vistos_recientes: [
      { producto_id: ObjectId("665f1a0000000000000a0001"), sku: "LAP-DELL-XPS15-001", ultima_vista: ISODate("2026-06-19T13:55:02Z") },
      { producto_id: ObjectId("665f1a0000000000000a0002"), sku: "TEC-LOGI-MX-002", ultima_vista: ISODate("2026-06-19T13:58:40Z") }
    ],
    productos_recomendados: [
      { producto_id: ObjectId("665f1a0000000000000a0004"), sku: "MON-LG-ULTRA-004", score: 0.92, motivo: "comprado_junto_con_laptops" },
      { producto_id: ObjectId("665f1a0000000000000a0003"), sku: "SOFT-ADOBE-CC-003", score: 0.74, motivo: "categoria_relacionada" }
    ],
    fecha_calculo: ISODate("2026-06-19T14:05:00Z")
  },
  {
    _id: ObjectId("665f4d0000000000000d0002"),
    id_cliente_sql: 9456,
    productos_vistos_recientes: [
      { producto_id: ObjectId("665f1a0000000000000a0004"), sku: "MON-LG-ULTRA-004", ultima_vista: ISODate("2026-06-19T16:10:15Z") }
    ],
    productos_recomendados: [
      { producto_id: ObjectId("665f1a0000000000000a0001"), sku: "LAP-DELL-XPS15-001", score: 0.81, motivo: "vistos_similares" }
    ],
    fecha_calculo: ISODate("2026-06-19T16:15:00Z")
  }
]);

// ------------------------------------------------------------
// 5. sesiones
// ------------------------------------------------------------
db.sesiones.deleteMany({});
db.sesiones.insertMany([
  {
    _id: "sess_abc123",
    id_usuario_sql: 501,
    ip: "190.45.12.88",
    user_agent: "Mozilla/5.0 (Linux; Android 14) Mobile",
    creada: ISODate("2026-06-19T13:50:00Z"),
    expira: ISODate("2026-06-19T17:50:00Z")
  },
  {
    _id: "sess_def456",
    id_usuario_sql: 487,
    ip: "186.103.5.21",
    user_agent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
    creada: ISODate("2026-06-18T10:55:00Z"),
    expira: ISODate("2026-06-18T14:55:00Z")
  },
  {
    _id: "sess_ghi789",
    id_usuario_sql: 533,
    ip: "201.78.220.14",
    user_agent: "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5)",
    creada: ISODate("2026-06-19T16:05:00Z"),
    expira: ISODate("2026-06-19T20:05:00Z")
  }
]);

// ------------------------------------------------------------
// 6. auditoria_nosql
// ------------------------------------------------------------
db.auditoria_nosql.deleteMany({});
db.auditoria_nosql.insertMany([
  {
    _id: ObjectId("665f5e0000000000000e0001"),
    coleccion_afectada: "productos",
    documento_id: ObjectId("665f1a0000000000000a0001"),
    accion: "actualizacion_precio",
    valor_anterior: 1200000,
    valor_nuevo: 1250000,
    origen: "api_proveedor",
    id_usuario_sql: null,
    timestamp: ISODate("2026-06-18T09:32:00Z")
  },
  {
    _id: ObjectId("665f5e0000000000000e0002"),
    coleccion_afectada: "productos",
    documento_id: ObjectId("665f1a0000000000000a0002"),
    accion: "actualizacion_stock",
    valor_anterior: 160,
    valor_nuevo: 152,
    origen: "api_proveedor",
    id_usuario_sql: null,
    timestamp: ISODate("2026-06-19T07:14:00Z")
  },
  {
    _id: ObjectId("665f5e0000000000000e0003"),
    coleccion_afectada: "carritos",
    documento_id: ObjectId("665f2b0000000000000b0003"),
    accion: "carrito_convertido_a_pedido",
    valor_anterior: "activo",
    valor_nuevo: "convertido",
    origen: "backend_python",
    id_usuario_sql: 487,
    timestamp: ISODate("2026-06-18T11:25:00Z")
  },
  {
    _id: ObjectId("665f5e0000000000000e0004"),
    coleccion_afectada: "logs_navegacion",
    documento_id: null,
    accion: "eliminacion_derecho_olvido",
    valor_anterior: "id_cliente_sql=9087",
    valor_nuevo: "anonimizado",
    origen: "backend_python",
    id_usuario_sql: 501,
    timestamp: ISODate("2026-06-15T10:00:00Z")
  }
]);

// ------------------------------------------------------------
// 7. resenas
// ------------------------------------------------------------
db.resenas.deleteMany({});
db.resenas.insertMany([
  {
    _id: ObjectId("665f6f0000000000000f0001"),
    producto_id: ObjectId("665f1a0000000000000a0001"),
    sku: "LAP-DELL-XPS15-001",
    id_cliente_sql: 9087,
    nombre_cliente: "Felipe R.",
    rating: 5,
    titulo: "Excelente para diseno grafico",
    comentario: "La pantalla OLED hace una diferencia enorme, muy recomendada.",
    verificada: true,
    fecha: ISODate("2026-05-02T18:20:00Z")
  },
  {
    _id: ObjectId("665f6f0000000000000f0002"),
    producto_id: ObjectId("665f1a0000000000000a0001"),
    sku: "LAP-DELL-XPS15-001",
    id_cliente_sql: 9456,
    nombre_cliente: "Camila T.",
    rating: 4,
    titulo: "Buena pero calienta un poco",
    comentario: "Buen rendimiento en general, la temperatura sube con cargas pesadas.",
    verificada: true,
    fecha: ISODate("2026-05-20T09:10:00Z")
  },
  {
    _id: ObjectId("665f6f0000000000000f0003"),
    producto_id: ObjectId("665f1a0000000000000a0002"),
    sku: "TEC-LOGI-MX-002",
    id_cliente_sql: 9123,
    nombre_cliente: "Enrique A.",
    rating: 5,
    titulo: "El mejor teclado que he tenido",
    comentario: "Silencioso y comodo para largas jornadas de trabajo.",
    verificada: true,
    fecha: ISODate("2026-06-01T12:45:00Z")
  }
]);

// ------------------------------------------------------------
// Verificacion rapida
// ------------------------------------------------------------
print("productos: " + db.productos.countDocuments());
print("carritos: " + db.carritos.countDocuments());
print("logs_navegacion: " + db.logs_navegacion.countDocuments());
print("recomendaciones: " + db.recomendaciones.countDocuments());
print("sesiones: " + db.sesiones.countDocuments());
print("auditoria_nosql: " + db.auditoria_nosql.countDocuments());
print("resenas: " + db.resenas.countDocuments());
